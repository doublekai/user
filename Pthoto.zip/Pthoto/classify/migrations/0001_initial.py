# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='image_calss',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('ic_name', models.CharField(max_length=50)),
            ],
        ),
        migrations.CreateModel(
            name='image_mag',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('im_name', models.CharField(max_length=50)),
                ('im_des', models.CharField(max_length=500)),
                ('im_adress', models.CharField(max_length=20)),
                ('im_cag', models.ForeignKey(to='classify.image_calss')),
            ],
        ),
    ]
