import request
from django.shortcuts import render


# Create your views here.
from classify.models import image_calss, image_mag


def index(request):
    ic_d=[]
    classify=image_calss.objects.all()
    ic = image_mag.objects.filter(im_cag=3)


    return render(request, 'index.html',{'classify':classify,'ic_d':ic_d})
