# coding=utf-8
from django.db import models


# Create your models here.
class image_calss(models.Model):
    ic_name = models.CharField(max_length=50)


class image_mag(models.Model):
    # 图片标题
    im_name = models.CharField(max_length=50)
    # 图片描述
    im_des = models.CharField(max_length=500)
    # 图片地址
    im_adress = models.CharField(max_length=20)
    # 图片分类
    im_cag = models.ForeignKey('image_calss')
